import tensorflow as tf
import time
import math
import random
import numpy as np
import os
import dataset_iris1

#Adding Seed so that random initialization is consistent
#from numpy.random import seed
#seed(1)
#from tensorflow import set_random_seed
#set_random_seed(2)

batch_size      = 16	
validation_size = 0.2

train_path      = './IRIS/'			
classes         = os.listdir(train_path)
sinif           = len(classes)
dimension     = 16				# The dimension of the Walsh vectors

#----------------------------------------------------------------
#--------- Labelling by Using Walsh Vectors ---------------------
data            = dataset_iris1.read_train_sets(train_path, classes, validation_size=validation_size)
a            , data_size, num_channels = data.train.images.shape
batch_size1  , b        , c            = data.valid.images.shape
#----------------------------------------------------------------------------------------

print("Complete reading input data. Will Now print a snippet of it")
print("Number of files in Training-set:\t\t{}".format(len(data.train.labels)))
print("Number of files in Validation-set:\t{}".format(len(data.valid.labels)))

session     = tf.Session()

x           = tf.placeholder(tf.float32, shape=[None, data_size, num_channels], name='x')
y_true      = tf.placeholder(tf.float32, shape=[None, dimension], name='y_true')

is_training = tf.placeholder(tf.bool , name ='is_training')


#----------------------------------------------------------------------------------------
#    WW1 in DivFE_iris must be same with WW1 in dataset_iris1
#----------------------------------------------------------------------------------------
WW1 = np.array([[1.0,1.0,1.0,1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,1.0,1.0,1.0,1.0],
       		[1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0],
       		[1.0,1.0,0.0,0.0,1.0,1.0,0.0,0.0,1.0,1.0,0.0,0.0,1.0,1.0,0.0,0.0]])
#WW1 = WW1 * 255.0
#----------------------------------------------------------------------------------------

#------------- Network graph params ------------------------------------------------------------------

filter_size_conv1  = 2		 
num_filters_conv1  = 10		

filter_size_conv2  = 2	 	
num_filters_conv2  = 10		

filter_size_conv3  = 2			
num_filters_conv3  = 10		

filter_size_conv4  = data_size		# data size  	
num_filters_conv4  = 16			#The dimension of the Walsh vektors
#-----------------------------------------------------

keep_rate          = 0.9
keep_prob          = tf.placeholder(tf.float32)

#-----------------------------------------------------
def create_weights(shape):
    return tf.Variable(tf.truncated_normal(shape, stddev=0.05))

def create_biases(size):
    return tf.Variable(tf.constant(0.05, shape=[size]))

def create_convolutional_layer(inputx,
               num_input_channels,
               conv_filter_size,
               num_filters, SV, MP, AF):

    global is_training
    ## We shall define the weights that will be trained using create_weights function.
    weights  = create_weights(shape=[conv_filter_size, num_input_channels, num_filters])
    ## We create biases using the create_biases function. These are also trained.
    biases   = create_biases(num_filters)

    if (SV==1):
    ## Creating the convolutional layer
        layer1   = tf.nn.conv1d(value = inputx,
                     filters          = weights,
                     stride           = 1,
                     padding          = 'VALID')
    if (SV==0):
    ## Creating the convolutional layer
        layer1   = tf.nn.conv1d(value = inputx,
                     filters          = weights,
                     stride           = 1,
                     padding          = 'SAME')

    layer1  += biases

    ## Batch Normalization
    BN           = tf.layers.batch_normalization(
        inputs   = layer1,
        training = is_training
    )    
    
    ## We shall be using max-pooling.
    if (MP==1):
#        layer3 = layer1
        layer3 = tf.layers.average_pooling1d(inputs =BN , pool_size= 2, strides=2, padding='same')
    else:
        layer3 = BN

    ## Output of pooling is fed to Relu which is the activation function for us.
    if (AF==0):
        layer4 = tf.nn.selu(layer3)
    if (AF==1):
        layer4 = tf.nn.sigmoid(layer3)
    if (AF==2):
        layer4 = tf.nn.tanh(layer3)
    if (AF==3):
        layer4 = tf.nn.relu(layer3)
    
    print ("layer ------>",layer4.shape)
    return layer4
#--------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------
#-------------- CNN  ------------------------------------------------------------------
layer_conv1 = create_convolutional_layer(inputx =	x,
               num_input_channels =			num_channels,
               conv_filter_size   =			filter_size_conv1,
               num_filters        =			num_filters_conv1,
               SV                 = 			0,
               MP                 = 			0,
               AF		  = 0)
layer_1     = tf.nn.dropout(layer_conv1, keep_rate)

layer_conv2 = create_convolutional_layer(inputx =	layer_1,
               num_input_channels =			num_filters_conv1,
               conv_filter_size   =			filter_size_conv2,
               num_filters        =			num_filters_conv2,
               SV                 = 			0,
               MP                 = 			0,
               AF		  = 0)
layer_2     = tf.nn.dropout(layer_conv2, keep_rate)

layer_conv3 = create_convolutional_layer(inputx =	layer_2,
               num_input_channels =			num_filters_conv2,
               conv_filter_size   =			filter_size_conv3,
               num_filters        =			num_filters_conv3,
               SV                 = 			0,
               MP                 = 			0,
               AF		  = 0)
layer_3     = tf.nn.dropout(layer_conv3, keep_rate)

#--------------------------------------------------------------------------------------
#-------------- Flatten Layer  --------------------------------------------------------
layer_conv4 = create_convolutional_layer(inputx =	layer_3,
               num_input_channels =			num_filters_conv3,
               conv_filter_size   =			filter_size_conv4,
               num_filters        =			num_filters_conv4,
               SV                 = 			1,		#Be careful always "No-maxpooling" in last layer	
               MP                 = 			0,		#Be careful always "VALID" in last layer		
               AF		  = 0)

layer_fc2   = tf.reshape(layer_conv4, [-1, dimension], name = "layer_fc2")		
#-------------------------------------------------------------

cost        = tf.reduce_mean(tf.square(layer_fc2 - y_true), name='cost')
#optimizer   = tf.train.AdamOptimizer(learning_rate=0.00001, name = 'optimizer').minimize(cost)
optimizer   = tf.train.GradientDescentOptimizer(learning_rate=0.0001, name = 'optimizer').minimize(cost)

summary_op2 =tf.summary.scalar("val_loss",cost)

session.run(tf.global_variables_initializer()) 


#------------------------------------------------------------------------------------
#------------ Training Accuracy by MDN ----------------------------------------------
def bul1(YY1, y_true_batch):
    global WW1, sinif

    ll     = 0
    a1, b1 = WW1.shape
    a2, b2 = YY1.shape

    yes = 0.0
    for i in range(0, a2):
        m1 = 100000000000000000000000000000000000000000000000000000000.0
        for j in range(0, sinif):
            m2 = 0.0
            for k in range(0, b1): 
                m2 = m2 + (YY1[i, k]-WW1[j, k])*(YY1[i, k]-WW1[j, k])
            if (m1 > m2):
                m1 = m2
                ll = j 

        c = np.all((WW1[ll,:] - y_true_batch[i,:])==0)
        if (c):
            yes = yes + 1
        else:
            yes = yes
        
    acc = yes/a2

    return acc

#------------------------------------------------------------------------------------
#------------ Test Accuracy by MDN --------------------------------------------------
def bul2(YY2, y_valid_batch):
    global WW1, sinif

    ll     = 0
    a1, b1 = WW1.shape
    a2, b2 = YY2.shape

    top, x = y_valid_batch.shape

    yes = 0.0

    for i in range(0, a2):
        m1 = 100000000000000000000000000000000000000000000000000000000.0
        for j in range(0, sinif):
            m2 = 0.0
            for k in range(0, b1): 
                m2 = m2 + (YY2[i, k]-WW1[j, k])*(YY2[i, k]-WW1[j, k])
            if (m1 > m2):
                m1 = m2
                ll = j 

        c = np.all((WW1[ll,:] - y_valid_batch[i,:])==0)
        if (c):
            yes = yes + 1.0
        else:
            yes = yes

    val_acc  = yes/top

    return val_acc
#--------------------------------------------------------------------------------------
   
total_iterations = 0
saver = tf.train.Saver()

toplam  = 0
toplam1 = 0
def train(num_iteration):
    global total_iterations

    train_writer=tf.summary.FileWriter("./graphs/train/",session.graph)
    valid_writer=tf.summary.FileWriter("./graphs/valid/",session.graph)

    for i in range(total_iterations, total_iterations + num_iteration):

#------------ Training --------------------------------------------------------------------------
        x_batch, y_true_batch = data.train.next_batch(batch_size)
        feed_dict_tr          = {x: x_batch, y_true: y_true_batch,is_training:True}

        extra_update_ops      = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        session.run([optimizer, extra_update_ops],feed_dict=feed_dict_tr)

        if i % int(data.train.num_examples/batch_size) == 0:

            epoch = int(i / int(data.train.num_examples/batch_size))

#------------ Test accuracy computing -----------------------------------------------------------
            x_valid_batch, y_valid_batch = data.valid.next_batch(batch_size1)

            feed_dict_tr  = {x: x_batch      , y_true: y_true_batch , is_training:False}
            feed_dict_val = {x: x_valid_batch, y_true: y_valid_batch, is_training:False}
#-----------------------------------------------------------------------------------------------
            YY1      = session.run(layer_fc2, feed_dict = feed_dict_tr)
            acc      = bul1(YY1, y_true_batch)					#get the training accuracy

            YY2      = session.run(layer_fc2, feed_dict = feed_dict_val)
            val_acc  = bul2(YY2, y_valid_batch)					#get the validation accuracy
#-----------------------------------------------------------------------------------------------
            val_loss = session.run(cost , feed_dict = feed_dict_val)
            tra_loss = session.run(cost , feed_dict = feed_dict_tr)
#-----------------------------------------------------------------------------------------------

            print ("Epoch:",epoch + 1, "acc:", acc, "val_acc:",val_acc,"val_loss:",val_loss, "tra_loss:", tra_loss)
 
            summary=session.run(summary_op2,feed_dict=feed_dict_tr)
            train_writer.add_summary(summary,epoch+1)
            summary2=session.run(summary_op2,feed_dict=feed_dict_val)
            valid_writer.add_summary(summary2,epoch+1)

            saver.save(session, './iris-model')

    train_writer.close()
    valid_writer.close()

    total_iterations += num_iteration
    #tensorboard --logdir="./graphs" --port 6006
train(num_iteration=2000000)

