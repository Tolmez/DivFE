import tensorflow as tf
import time
from datetime import timedelta
import math
import random
import numpy as np
import os
import dataset_cats_dogs1

#Adding Seed so that random initialization is consistent
#from numpy.random import seed
#seed(1)
#from tensorflow import set_random_seed
#set_random_seed(2)

batch_size  	= 40	
image_sizeX     = 128
image_sizeY     = 128

validation_size = 0.2

train_path      = './CatsDogs_Train/'
valid_path      = './CatsDogs_Valid/'			
Tclasses        = os.listdir(train_path)
Vclasses        = os.listdir(valid_path)
sinif           = len(Tclasses)
dimension       = 16				# Dimension of the Walsh vectors 

#----------------------------------------------------------------------------------------------------
#--------- Labelling by Using Walsh Vectors ---------------------------------------------------------
data   = dataset_cats_dogs1.read_train_sets(train_path, valid_path, image_sizeX,image_sizeY, Tclasses, Vclasses, validation_size=validation_size)

#----------------------------------------------------------------------------------------------------

a            , data_size1, data_size2, num_channels = data.train.images.shape
batch_size1  , b1        , b2        , c            = data.valid.images.shape

print("Complete reading input data. Will Now print a snippet of it")
print("Number of files in Training-set:\t\t{}".format(len(data.train.labels)))
print("Number of files in Validation-set:\t{}".format(len(data.valid.labels)))

session     = tf.Session()

x           = tf.placeholder(tf.float32, shape=[None, data_size1, data_size2, num_channels], name='x')
y_true      = tf.placeholder(tf.float32, shape=[None, dimension], name='y_true')
is_training = tf.placeholder(tf.bool , name ='is_training')

#------ Walsh vectors for the two classes ------------------------------------------------------------
WW1 = np.array([[1.0,1.0,1.0,1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,1.0,1.0,1.0,1.0],
       		[1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0]])
#WW1 = WW1 * 255.0

#------------- Network graph params ------------------------------------------------------------------
filter_size_conv1x  = 11		
filter_size_conv1y  = 11
num_filters_conv1   = 50	

filter_size_conv2x  = 9		
filter_size_conv2y  = 9
num_filters_conv2   = 50	

filter_size_conv3x  = 7		
filter_size_conv3y  = 7
num_filters_conv3   = 50	

filter_size_conv4x  = 5		
filter_size_conv4y  = 5	
num_filters_conv4   = 50	

filter_size_conv5x  = 3
filter_size_conv5y  = 3	
num_filters_conv5   = 50		    

filter_size_conv6x  = 4
filter_size_conv6y  = 4	
num_filters_conv6   = 16		    

filter_size_conv7x  = 4
filter_size_conv7y  = 4	
num_filters_conv7   = 16		    
#-----------------------------------------------------------------------------------------------------
keep_rate=0.9
keep_prob=tf.placeholder(tf.float32)

def create_weights(shape):
    return tf.Variable(tf.truncated_normal(shape, stddev=0.05))

def create_biases(size):
    return tf.Variable(tf.constant(0.05, shape=[size]))

def create_convolutional_layer(inputx,
               num_input_channels,
               conv_filter_sizeX,
               conv_filter_sizeY,
               num_filters, SV,MP,RE):

    global is_training
    ## We shall define the weights that will be trained using create_weights function.
    weights  = create_weights(shape=[conv_filter_sizeX, conv_filter_sizeY, num_input_channels, num_filters])
    ## We create biases using the create_biases function. These are also trained.
    biases   = create_biases(num_filters)

    if (SV==0):
    ## Creating the convolutional layer
        layer1x   = tf.nn.conv2d(input = inputx,
                     filter       = weights,
                     strides      = [1, 1, 1, 1],
                     padding      = 'VALID')

    if (SV==1):	
    ## Creating the convolutional layer
        layer1x   = tf.nn.conv2d(input = inputx,
                     filter       = weights,
                     strides      = [1, 1, 1, 1],
                     padding      = 'SAME')

    layer1  = layer1x + biases
    
   
    BN           = tf.layers.batch_normalization(
        inputs   = layer1,
        training = is_training
    )    

    ## We shall be using max-pooling.
    if (MP==0):
        layer2 = tf.nn.max_pool(value   = BN,
                                ksize   = [1, 2, 2, 1],
                                strides = [1, 2, 2, 1],
                                padding = 'SAME')
    
    if (MP==1):
        layer2 = BN

    ## Output of pooling is fed to Relu which is the activation function for us.
    if (RE==0):
        layer3   = tf.nn.selu(layer2)
    if (RE==1):
        layer3   = tf.nn.relu(layer2)
    if (RE==2):
        layer3   = tf.nn.sigmoid(layer2)
    if (RE==3):
        layer3   = tf.nn.tanh(layer2)
   
    print ("layer ------>",layer3.shape)
    return layer3

#---------------------------------------------------------------------------------------------------------
layer_conv1 = create_convolutional_layer(inputx=	x,
               num_input_channels =			num_channels,
               conv_filter_sizeX  =			filter_size_conv1x,
               conv_filter_sizeY  =			filter_size_conv1y,
               num_filters        =			num_filters_conv1,
               SV                 = 			1,
               MP		  = 			0,
               RE                 =                     0)
layer_1     = tf.nn.dropout(layer_conv1, keep_rate)

layer_conv2 = create_convolutional_layer(inputx=	layer_1,
               num_input_channels =			num_filters_conv1,
               conv_filter_sizeX  =			filter_size_conv2x,
               conv_filter_sizeY  =			filter_size_conv2y,
               num_filters        =			num_filters_conv2,
               SV                 = 			1,
               MP		  = 			0,
               RE                 =                     0)
layer_2     = tf.nn.dropout(layer_conv2, keep_rate)

layer_conv3 = create_convolutional_layer(inputx=	layer_2,
               num_input_channels =			num_filters_conv2,
               conv_filter_sizeX  =			filter_size_conv3x,
               conv_filter_sizeY  =			filter_size_conv3y,
               num_filters        =			num_filters_conv3,
               SV                 =  			1,
               MP		  = 			0,
               RE                 =                     0)

layer_3     = tf.nn.dropout(layer_conv3, keep_rate)

layer_conv4 = create_convolutional_layer(inputx=	layer_3,
               num_input_channels =			num_filters_conv3,
               conv_filter_sizeX  =			filter_size_conv4x,
               conv_filter_sizeY  =			filter_size_conv4y,
               num_filters        =			num_filters_conv4,
               SV                 =  			1,
               MP		  = 			0,
               RE                 =                     0)

layer_4     = tf.nn.dropout(layer_conv4, keep_rate)

layer_conv5 = create_convolutional_layer(inputx=	layer_4,
               num_input_channels =			num_filters_conv4,
               conv_filter_sizeX  =			filter_size_conv5x,
               conv_filter_sizeY  =			filter_size_conv5y,
               num_filters        =			num_filters_conv5,
               SV                 =  			1,				
               MP		  = 			0,				
               RE                 =                     0)

layer_5     = tf.nn.dropout(layer_conv5, keep_rate)

#--------------------------------------------------------------------------------------------------------------------
#-------------- Flatten Layer  --------------------------------------------------------------------------------------
layer_conv6 = create_convolutional_layer(inputx=	layer_5,
               num_input_channels =			num_filters_conv5,
               conv_filter_sizeX  =			filter_size_conv6x,
               conv_filter_sizeY  =			filter_size_conv6y,
               num_filters        =			num_filters_conv6,
               SV                 =  			0,		#Be careful always "VALID" in last layer	
               MP		  = 			1,		#Be careful always "No-maxpooling" in last layer	
               RE                 =                     0)

layer_fc2 = tf.reshape(layer_conv6, [-1, dimension], name = "layer_fc2")		

#-----------------------------------------------------------------------------------------------------------------

cost       = tf.reduce_mean(tf.square(layer_fc2 - y_true), name='cost')
optimizer  = tf.train.AdamOptimizer(learning_rate=0.0001, name = 'optimizer').minimize(cost)
#optimizer  = tf.train.GradientDescentOptimizer(learning_rate=0.0001, name = 'optimizer').minimize(cost)

#summary_op=tf.summary.scalar("accuracy",accuracy)
#summary_op2=tf.summary.scalar("val_loss",cost)

session.run(tf.global_variables_initializer()) 

#------------------------------------------------------------------------------------------------------------------
#------------ Finding Training Accuracy by MDN --------------------------------------------------------------------
def bul1(YY1, y_true_batch):
    global WW1, sinif

    ll     = 0
    a1, b1 = WW1.shape
    a2, b2 = YY1.shape

    yes = 0.0
    for i in range(0, a2):
        m1 = 100000000000000000000000000000000000000000000000000000000.0
        for j in range(0, sinif):
            m2 = 0.0
            for k in range(0, b1): 
                m2 = m2 + (YY1[i, k]-WW1[j, k])*(YY1[i, k]-WW1[j, k])
            if (m1 > m2):
                m1 = m2
                ll = j 

        c = np.all((WW1[ll,:] - y_true_batch[i,:])==0)
        if (c):
            yes = yes + 1
        else:
            yes = yes
        
    acc = yes/a2

    return acc

#------------------------------------------------------------------------------------
#------------ Finding Test Accuracy by MDN ------------------------------------------
def bul2(YY2, y_valid_batch):
    global WW1, sinif

    ll     = 0
    a1, b1 = WW1.shape
    a2, b2 = YY2.shape

    top, x = y_valid_batch.shape

    yes   = 0.0
    for i in range(0, a2):
        m1 = 100000000000000000000000000000000000000000000000000000000.0
        for j in range(0, sinif):
            m2 = 0.0
            for k in range(0, b1): 
                m2 = m2 + (YY2[i, k]-WW1[j, k])*(YY2[i, k]-WW1[j, k])
            if (m1 > m2):
                m1 = m2
                ll = j 

        c = np.all((WW1[ll,:] - y_valid_batch[i,:])==0)
        if (c):
            yes = yes + 1.0
        else:
            yes = yes

    val_acc  = yes	

    return val_acc
#------------------------------------------------------------------------------------
   
total_iterations = 0
saver = tf.train.Saver()

def train(num_iteration):
    global total_iterations

    for i in range(total_iterations, total_iterations + num_iteration):

#------------ Training --------------------------------------------------------------------------
        x_batch, y_true_batch = data.train.next_batch(batch_size)
        feed_dict_tr          = {x: x_batch, y_true: y_true_batch,is_training:True}

        extra_update_ops      = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        session.run([optimizer, extra_update_ops],feed_dict=feed_dict_tr)

#------------ Test accuracy computing -----------------------------------------------------------
        if i % int(data.train.num_examples/batch_size) == 0:

            epoch = int(i / int(data.train.num_examples/batch_size))

#-------------------------------------------------------------------------------------------------
            feed_dict_tr = {x: x_batch, y_true: y_true_batch , is_training:False}
            YY1          = session.run(layer_fc2, feed_dict = feed_dict_tr)
            acc          = bul1(YY1, y_true_batch)			#get the training accuracy
#-------------------------------------------------------------------------------------------------
            sayi    = int(batch_size1/28)
            Sum  = 0
            for tt in range(0, sayi):
                x_valid_batch, y_valid_batch = data.valid.next_batch(28)
                feed_dict_val = {x: x_valid_batch, y_true: y_valid_batch, is_training:False}
                YY2           = session.run(layer_fc2, feed_dict = feed_dict_val)
                val_acc       = bul2(YY2, y_valid_batch)
                Sum           = Sum  + val_acc				#get the validation accuracy
            valid_acc  = Sum/batch_size1				
#-------------------------------------------------------------------------------------------------
            x_valid_batch, y_valid_batch = data.valid.next_batch(batch_size1)
            feed_dict_val = {x: x_valid_batch, y_true: y_valid_batch, is_training:False}
            loss          = session.run(cost, feed_dict = feed_dict_val)
#-------------------------------------------------------------------------------------------------
            print ("---------------------------------------------------------------------")
            print ("Epoch:",epoch + 1, "acc:", acc, "val_acc:",valid_acc, "loss:", loss)
            print ("---------------------------------------------------------------------")
            saver.save(session, './Cats_Dogs-model')

    #train_writer.close()
    #valid_writer.close()

    total_iterations += num_iteration
    #tensorboard --logdir="./graphs" --port 6006
train(num_iteration=200000)

