import cv2
import os
import glob
from sklearn.utils import shuffle
import numpy as np
import scipy.io as sio
import random

WW1 = np.array([[1.0,1.0,1.0,1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,1.0,1.0,1.0,1.0],
       		[1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0,1.0,0.0]])
#WW1 = WW1*255.0

def load_train(train_path, image_sizeX,image_sizeY, classes):
    global image,dizi,KSayi, Kof
    images = []
    labels = []

    Buf2 = np.zeros((image_sizeX, image_sizeX, 3)).astype(np.float64)

    print('Going to read training images')
    for fields in classes:   
        index = classes.index(fields)
        print('Now going to read {} files (Index: {})'.format(fields, index))
        path = os.path.join(train_path, fields, '*')
        files = glob.glob(path)
        for fl in files:
#----------------------------------------------------------------------------
            image = cv2.imread(fl)
            image = cv2.resize(image, (image_sizeX, image_sizeY),0,0, cv2.INTER_LINEAR)

            #Buf2[:,:,0]  = (image[:,:,0] + image[:,:,1] + image[:,:,2])/3
            #Buf2[:,:,1]  = (image[:,:,0] + image[:,:,1] + image[:,:,2])/3
            #Buf2[:,:,2]  = (image[:,:,0] + image[:,:,1] + image[:,:,2])/3
            Buf3         = image.astype(np.uint8)				# Gray Image
            
            images.append(Buf3.copy())
#----------------------------------------------------------------------------
            label = WW1[index,:]				#Walsh Vectors 
            labels.append(label.copy())
#----------------------------------------------------------------------------

    images = np.array(images)
    labels = np.array(labels)

    return images, labels


class DataSet(object):

  def __init__(self, images, labels):
    self._num_examples = images.shape[0]

    self._images = images
    self._labels = labels
    self._epochs_done = 0
    self._index_in_epoch = 0

  @property
  def images(self):
    return self._images

  @property
  def labels(self):
    return self._labels

  @property
  def num_examples(self):
    return self._num_examples

  @property
  def epochs_done(self):
    return self._epochs_done

  def next_batch(self, batch_size):
    """Return the next `batch_size` examples from this data set."""
    start = self._index_in_epoch
    self._index_in_epoch += batch_size

    if self._index_in_epoch > self._num_examples:
      # After each epoch we update this
      self._epochs_done += 1
      start = 0
      self._index_in_epoch = batch_size
      assert batch_size <= self._num_examples
    end = self._index_in_epoch

    return self._images[start:end], self._labels[start:end]


def read_train_sets(train_path, valid_path, image_sizeX,image_sizeY, Tclasses, Vclasses, validation_size):
  class DataSets(object):
    pass
  data_sets = DataSets()

  train_images, train_labels   = load_train(train_path, image_sizeX, image_sizeY, Tclasses)
  train_images, train_labels   = shuffle(train_images, train_labels)  
    
  train_images = np.array(train_images)
  train_lables = np.array(train_labels)

  """  
#------------------------------------------------------------------------------
#----------- Augmentation of Only Training Set --------------------------------
  a,b,c,d =train_images.shape

  images1 = []
  labels1 = []  
  for ii in range(0, a):
    xx0 = train_images[ii]
    images1.append(xx0.copy())
    labels1.append(train_lables[ii,:].copy())

    for j in range(0,4):
      if (random.randint(0,1)):
        xx1      = 255 - xx0
      else:
        xx1      = xx0
        
#     if (random.randint(0,1)):       
#       gauss    = np.random.normal(0, 15, (image_sizeX, image_sizeY, 0))
#       gauss    = gauss - min(gauss.flatten())
#       xx2      = xx1 + gauss    
#     else:
#       xx2      = xx1
      xx2 = xx1

      if (random.randint(0,1)):
        aa       = random.randint(5,8)
        bb       = aa/10.0
        xx3x     = xx2*bb
        xx3      = xx3x.astype(np.uint8)
      else:
        xx3      = xx2

      if (random.randint(0,1)):
        xx4      = cv2.flip(xx3, 0)   
      else:
        xx4      = xx3

      if (random.randint(0,1)):
        xx5      = cv2.flip(xx4, 1)   
      else:
        xx5      = xx4
      
      images1.append(xx5.copy())
      labels1.append(train_lables[ii,:].copy())

  train_images = np.array(images1)
  train_labels = np.array(labels1)
  """  
#------------------------------------------------------------------------------

  data_sets.train = DataSet(train_images, train_labels)

  validation_images, validation_labels   = load_train(valid_path, image_sizeX, image_sizeY, Vclasses)
  validation_images, validation_labels   = shuffle(validation_images, validation_labels)  

  validation_images = np.array(validation_images)
  validation_lables = np.array(validation_labels)
  data_sets.valid = DataSet(validation_images, validation_labels)

  return data_sets


